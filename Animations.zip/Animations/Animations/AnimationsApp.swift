import SwiftUI

@main
struct AnimationsApp: App {
    var body: some Scene {
        WindowGroup {
            AnimationExampleView()
        }
    }
}

struct AnimationExampleView: View {
    @State private var animated = false
    
    // Static animations array with a duration of 5 seconds for each animation
    let animations: [(String, Animation)] = [
        ("linear", .linear(duration: 3)), // Set 5 seconds duration
        ("ease", .easeInOut(duration: 3)), // Set 5 seconds duration
        ("ease-in", .easeIn(duration: 3)), // Set 5 seconds duration
        ("ease-out", .easeOut(duration: 3)), // Set 5 seconds duration
        ("ease-in-out", .easeInOut(duration: 3)), // Set 5 seconds duration
        ("spring", .spring(response: 3, dampingFraction: 0.3, blendDuration: 0.5)), // Spring with 5 seconds response
//        ("interpolatingSpring", .interpolatingSpring(mass: 1.0, stiffness: 150.0, damping: 10.0, initialVelocity: 5.0)
//), // Interpolating Spring animation
        /*
         Response (3 seconds): This controls the speed of the spring's oscillation. It determines how long the spring will take to complete one cycle (move forward and settle). In your case, it is set to 3, meaning the animation will last approximately 3 seconds.

         Damping Fraction (0.6): This controls the amount of damping or "friction" applied to the spring as it moves. A value of 0 means no damping, resulting in continuous oscillation, while a value of 1 means full damping (no oscillation at all, moving directly to the end). In your case, the value of 0.6 means the motion will overshoot slightly and bounce before settling.

         Blend Duration (0.5 seconds): This controls the duration for which the spring animation blends with other animations. In this case, you’re blending it for 0.5 seconds, meaning the transition between other animations and the spring animation will be smooth.
         */
        ("cubic-bezier", Animation.timingCurve(0.1, 0.8, 0.2, 1, duration: 3)), // Set 5 seconds duration
        /*
         First control point (0.1, 0.8): This makes the animation start very smoothly and accelerate quickly as it moves.
         Second control point (0.2, 1): This makes the animation decelerate slowly as it approaches the end, making the movement more pronounced.

         Duration (3 seconds): The total duration of the animation is 3 seconds.
         */
    ]
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Swift Animations")
                .font(.title2)
                .bold()
                .foregroundColor(.white)
                .padding(.top, 20)

            ForEach(animations, id: \.0) { animation in
                HStack(alignment: .top) {
                    // Animation name on the left side
                    Text(animation.0)
                        .font(.system(size: 16, weight: .medium))
                        .frame(width: 100, alignment: .leading)
                        .foregroundColor(.white)
                    
                   // Spacer()

                    // Car running on road
                   VStack(alignment: .leading) {
                        // Car emoji, positioned on the road
                        Text("🚗")
                            .font(.title)
                            .scaleEffect(x: -3, y: 2) // Flips the car to face the right
                            .offset(x: animated ? 200 : 0, y: 10) // Car moves along the road
                            .animation(animation.1, value: animated)
                    
                       Rectangle()
                           .fill(Color.gray)
                           .frame(width: 250, height: 3) // Road with fixed width
                    }
                }
            }
            .frame(maxWidth: .infinity)
            
            Spacer()
            
            // Animate button
            Button("Animate") {
                animated.toggle()
            }
            .padding(.top, 10)
            .foregroundColor(.yellow)
        }
        .padding(.all, 20) // Padding around the entire view
        .background(Color.black)
    }
}

#Preview {
    AnimationExampleView()
}
